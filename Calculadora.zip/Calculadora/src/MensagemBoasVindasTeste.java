import static org.junit.Assert.*;


import org.junit.Test;

public class MensagemBoasVindasTeste {

	@Test
	public void testeRetornoMensagemJoao() {
		MensagemBoasVindas mens = new MensagemBoasVindas();
		String mensRetornoReal = mens.geraMensagem("Joao");
		String mensRetornoEsperado = "Seja bem vindo(a) sua calculadora, Joao";
		assertEquals(mensRetornoReal, mensRetornoEsperado);
	}

}
