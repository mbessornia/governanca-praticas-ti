
public class MensagemBoasVindas {
	
	String geraMensagem(String nomeUsuario) {
		String mensRetorno = ("Seja bem vindo(a) sua calculadora, "+ nomeUsuario);
		return mensRetorno;
	}

}
