package Testes;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import org.junit.Before;
import org.junit.After;



import Fontes.Calculadora;

public class CalculadoraTeste {
	
	private Calculadora calc;
	private String nomeTeste;
	private double resultadoReal;
	
	@Before
	public void inicioTeste() {
		System.out.println("Inciando o cálculo ");
		calc = new Calculadora();
	}
	
	@After
	public void terminoTeste() {
		System.out.println(nomeTeste);
		System.out.println("Cálculo finalizado. Resultado: "+resultadoReal);
	}

	@Test
	// Teste de soma
	public void testeSomar3com2() {
		nomeTeste = "Somar 3.5 com 2.5";
		resultadoReal = calc.somar(3, 2);
		double resultadoEsperado = 5;
		assertEquals(resultadoReal, resultadoEsperado, 0);
		System.out.println("Vou rodar o método de soma com inteiros.");
		System.out.println("O resultado é:" + calc.somar(3, 2));
	}

	@Test
	public void testeSomar3ponto5com2ponto5() {
		nomeTeste = "Somar 3.5 com 2.5";
		resultadoReal = calc.somar(3.5, 2.5);
		double resultadoEsperado = 6;
		assertEquals(resultadoReal, resultadoEsperado, 0);
		System.out.println("Vou rodar o método de soma com decimais.");
		System.out.println("O resultado é:" + calc.somar(3.5, 2.5));
		
	}

	@Test
	public void testeSubtrair2ponto5de3ponto5() {
		nomeTeste = "Subtrair 2.5 com 3.5";
		resultadoReal = calc.subtrair(3.5, 2.5);
		double resultadoEsperado = 1;
		assertEquals(resultadoReal, resultadoEsperado, 0);
		System.out.println("Vou rodar o método de subtração.");
		System.out.println("O resultado é:" + calc.subtrair(3.5, 2.5));
	}
		

	@Test
	public void testeDividir6por2() {
		nomeTeste = "Dividir 6 por 2";
		resultadoReal = calc.dividir(2, 6);
		double resultadoEsperado = 3;
		assertEquals(resultadoReal, resultadoEsperado, 0);
		System.out.println("Vou rodar o método de divisão.");
		System.out.println("O resultado é:" + calc.dividir(2, 6));

	}

}
