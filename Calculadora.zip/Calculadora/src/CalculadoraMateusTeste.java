import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculadoraMateusTeste {

	@Test
	// Teste de soma
	public void testeSomar3com2() {
		CalculadoraMateus calc = new CalculadoraMateus();
		double resultadoReal = calc.Somar(3, 2);
		double resultadoEsperado = 5;
		assertEquals(resultadoReal, resultadoEsperado, 0);
		;
	}

	@Test
	public void testeSomar3ponto5com2ponto5() {
		CalculadoraMateus calc = new CalculadoraMateus();
		double resultadoReal = calc.Somar(3.5, 2.5);
		double resultadoEsperado = 6;
		assertEquals(resultadoReal, resultadoEsperado, 0);
		;
	}

	@Test
	public void testeSubtrair2ponto5de3ponto5() {
		CalculadoraMateus calc = new CalculadoraMateus();
		double resultadoReal = calc.Subtrair(3.5, 2.5);
		double resultadoEsperado = 1;
		assertEquals(resultadoReal, resultadoEsperado, 0);
	}
		

	@Test
	public void testeDividir6por2() {
		CalculadoraMateus calc = new CalculadoraMateus();
		double resultadoReal = calc.Dividir(2, 6);
		double resultadoEsperado = 3;
		assertEquals(resultadoReal, resultadoEsperado, 0);
		;

	}

}
