
public class CalculadoraMateus {
	private double resultado = 0;
	
	
	
	public double Somar(double num1, double num2) {
		double resultado = num1 + num2;
		return resultado;
	}
	
	public double Subtrair(double num1, double num2) {
		double resultado = num1 - num2;
		return resultado;
	}
	
	public double Mult(double num1, double num2) {
		double resultado = num1 * num2;
		return resultado;
	}
	
	public double Dividir(double num1, double num2) {
		if (num1 != 0) {
		resultado = num2 / num1;
		} else {
			System.out.println("Erro: divisão por zero não é permitida.");
		}
		return resultado;
		
	}
	

}
